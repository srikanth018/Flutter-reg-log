package com.example.login_registeration

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
